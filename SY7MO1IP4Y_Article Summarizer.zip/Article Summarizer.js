const apiUrl = "https://text-summarization-api.p.rapidapi.com/summarize";
const apiKey = "YOUR_RAPIDAPI_KEY"; // Replace with your actual API key

const summarizeButton = document.getElementById('summarizeBtn');
const urlInput = document.getElementById('urlInput');
const loadingMessage = document.getElementById('loadingMessage');
const summaryOutput = document.getElementById('summaryOutput');

summarizeButton.addEventListener('click', () => {
    const articleUrl = urlInput.value.trim();

    if (articleUrl === "") {
        alert("Please enter a valid URL.");
        return;
    }

    loadingMessage.classList.remove('hidden');
    summaryOutput.innerHTML = '';

    // Fetch the summary using RapidAPI
    fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-RapidAPI-Key': apiKey,
                'X-RapidAPI-Host': 'text-summarization-api.p.rapidapi.com'
            },
            body: JSON.stringify({
                url: articleUrl
            })
        })
        .then(response => response.json())
        .then(data => {
            loadingMessage.classList.add('hidden');
            if (data.summary) {
                summaryOutput.innerHTML = `<h3>Summary:</h3><p>${data.summary}</p>`;
            } else {
                summaryOutput.innerHTML = "<p>Sorry, we couldn't summarize the article. Please try again.</p>";
            }
        })
        .catch(error => {
            loadingMessage.classList.add('hidden');
            summaryOutput.innerHTML = "<p>Error fetching the summary. Please try again later.</p>";
            console.error("Error:", error);
        });
});